package model;

public class Item {
    public String name;
}
