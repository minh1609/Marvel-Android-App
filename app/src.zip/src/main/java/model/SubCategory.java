package model;

public class SubCategory {
    public Item[] items;
}
