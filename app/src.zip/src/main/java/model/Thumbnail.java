package model;

public class Thumbnail {
    public String path;
    public String extension;
}
