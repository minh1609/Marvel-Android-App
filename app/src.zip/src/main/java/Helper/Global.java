package Helper;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class Global {
    public static final String baseUrl = "https://gateway.marvel.com:443/v1/public";
    public static final String secureParams = "?apikey=4b06c3ba829b4f67df951727a1a31477&ts=1564731162583&hash=67a40430571fb95fdd0a0180c9d44410";


}
